#!/bin/bash

####### ovpnconfig-cli2site: Criacao de servidores openvpn Client to Site
####### Autor: Eder Ferreira <eder.ferreira@ogasec.com>, <eder@pradotelecom.com>
####### Data: 2020-07-15
####### Versao: 1.0
# -----------------------------------------------------------------------


DirServer="/etc/ovpnconfig-cli2site/templates/servers"
DirClient="/etc/ovpnconfig-cli2site/templates/clients"
DirOpenvpn="/etc/openvpn"
DirCertificados="/etc/ovpnconfig-cli2site/easyrsa3/pki"
Workplace="/etc/ovpnconfig-cli2site/easyrsa3"

CRIA_CA(){
clear
echo "!!! Todos os certificados anteriores serao removidos !!! Deseja Continuar?"
echo "Digite 'sim' para continuar ou qualquer teclha para abortar"
read Resposta

case $Resposta in
	sim) echo "Criando Autoridade Certificadora - Responda o que se pede" ;;
	*) echo "Criacao abortada"; exit 1 ;;
esac
	cd "$Workplace"
	./easyrsa init-pki
	./easyrsa build-ca nopass
	./easyrsa gen-crl
	./easyrsa gen-dh
}

SERVER_VPN_CONFIG(){
   VpnInterfaceName="$2"
   VpnServerPort="$3"
   VpnServerProto="$4"
   VpnServerNetworkOvpn="$5"
   VpnServerMaskOvpn="$6"
   VpnServerIpAddr="$7"

cd "$Workplace"
./easyrsa build-server-full "$VpnInterfaceName" nopass

# Diretorios de configuracao do servidor
mkdir -p "$DirServer"/"$VpnInterfaceName"/certificados
mkdir -p "$DirServer"/"$VpnInterfaceName"/ccd
mkdir -p "$DirServer"/"$VpnInterfaceName"/logs

# Certificados do servidor Ovpn
mv "$Workplace"/pki/issued/"$VpnInterfaceName"* "$DirServer"/"$VpnInterfaceName"/certificados
mv "$Workplace"/pki/private/"$VpnInterfaceName"* "$DirServer"/"$VpnInterfaceName"/certificados
mv "$Workplace"/pki/reqs/"$VpnInterfaceName"* "$DirServer"/"$VpnInterfaceName"/certificados

# Template de configuracao do servidor
echo "port $VpnServerPort
proto $VpnServerProto
dev $VpnInterfaceName
dev-type tun
topology subnet
ca "$DirCertificados/ca.crt"
dh "$DirCertificados/dh.pem"
crl-verify "$DirCertificados/crl.pem"
cert "$DirOpenvpn"/"$VpnInterfaceName"/certificados/"$VpnInterfaceName".crt
key "$DirOpenvpn"/"$VpnInterfaceName"/certificados/"$VpnInterfaceName".key
client-config-dir "$DirOpenvpn"/"$VpnInterfaceName"/ccd
ccd-exclusive
keepalive 5 15
comp-lzo
persist-key
persist-tun
mssfix 1300
verb 3
cipher AES-256-CBC
auth SHA512
float
status "$DirOpenvpn"/"$VpnInterfaceName"/logs/status-"$VpnInterfaceName".log 10
log-append "$DirOpenvpn"/"$VpnInterfaceName"/logs/logs-"$VpnInterfaceName".log
status-version 3
server "$VpnServerNetworkOvpn" "$VpnServerMaskOvpn"
#push "route 10.0.0.0 255.224.0.0"
#push "route 3.3.3.0 255.255.255.0"
#push "dhcp-option DNS 10.0.0.17"
#push "dhcp-option WINS 10.0.0.17"
#push "dhcp-option DOMAIN aker.com.br"
daemon
writepid /var/run/openvpn-$VpnInterfaceName.pid" > "$DirServer"/"$VpnInterfaceName"/"$VpnInterfaceName".conf
mv "$DirServer"/"$VpnInterfaceName" "$DirOpenvpn"

#/etc/init.d/openvpn restart
}

CLIENT_VPN_CONFIG() {
        Server="$2"
	user="$3"
        Network="$4"
        Host="$5"
        Porta="$6"
        ServerIp="$7"

mkdir -p "$DirOpenvpn"/"$Server"/user

        # Muda para o diretorio do easyRSA3
        #
        cd "$Workplace"

        # Executa o script easyrsa para criacao do certificado
        #
        ./easyrsa build-client-full $user nopass >> /dev/null

        # Cria associacao do user com um endereco IP especifico
        echo "ifconfig-push "$Network"."$Host" 255.255.255.0" > "$DirOpenvpn"/"$Server"/ccd/"$user"

        # Cria o arquivo de configuracao do user de VPN
        #
        echo -e "client\ndev tun\nproto tcp\nresolv-retry 60\nnobind\npersist-key\npersist-tun\nremote-cert-tls server\n<ca>" > "$DirOpenvpn"/"$Server"/user/$user.ovpn
        cat "$DirCertificados"/ca.crt >> "$DirOpenvpn"/"$Server"/user/$user.ovpn
        echo -e "</ca>\n<cert>" >> "$DirOpenvpn"/"$Server"/user/$user.ovpn
        cat "$DirCertificados"/issued/$user.crt | grep -A 30 BEGIN |grep -B 30 "END CERTIFICATE" >> "$DirOpenvpn"/"$Server"/user/$user.ovpn
        echo -e "</cert>\n<key>" >> "$DirOpenvpn"/"$Server"/user/$user.ovpn
        cat "$DirCertificados"/private/$user.key >> "$DirOpenvpn"/"$Server"/user/$user.ovpn
        echo -e "</key>\nauth-user-pass\ncomp-lzo\ncipher AES-256-CBC\nauth SHA512\nfloat\nverb 1\nremote "$ServerIp" "$Porta"" >> "$DirOpenvpn"/"$Server"/user/$user.ovpn

        # Incrementa o arquivo "/etc/openvpn/.serial.txt".
        #
        SERIAL=$(( $(cat "$Workplace"/pki/.serial.txt) + 1 ))
        echo $SERIAL > "$Workplace"/pki/.serial.txt
        echo
        echo "O arquivo de configuracao esta salvo em "$DirOpenvpn"/"$Server"/user/$user.ovpn\n\n"
        echo

}

HELP(){
   echo ""
   echo "Parametro invalido!! - USE: $0 (cria-ca|server-vpn-config|client-config)"
   echo -e "\e[33mExemplo: \e[0m"
   echo -e "$0 \e[32mcria-ca\e[0m"
   echo -e "$0 \e[32mserver-vpn-config\e[0m tunsrv2001 2001 tcp 100.101.1.0 255.255.255.0 100.101.1.1"
   echo -e "$0 \e[32mclient-config\e[0m tunsrv2001 client1 100.101.1 2 2001 189.110.110.110"

}
        user="$1"
        Network="$2"
        Host="$3"
        Porta="$4"
        Server="$5"


case $1 in
   server-vpn-config) SERVER_VPN_CONFIG $*	;;
   client-config) CLIENT_VPN_CONFIG $* ;;
   cria-ca) CRIA_CA ;;
   *) HELP ;;
esac
