clear
echo "TODOS CERTIFICADOS SERAO REMOVIDOS!!!"
echo "Deseja realmente continuar ?"
read -p "Escreva \"SIM\": " OPCAO
 case "$OPCAO" in
	 SIM)  ;;
	 *) exit 1 ;;
 esac

 source variaveis.txt


 cd "$OPENVPN_DIR"/"$SERVER_NAME/easyrsa3" 
 rm -r pki

echo "Criando nova estrutura de diretorios"; sleep 1
./easyrsa init-pki

echo "Criando certificadora Raiz" sleep 1
./easyrsa build-ca nopass; echo -e "\n"

echo "Criando Certificados do Servidor VPN"; sleep 1
./easyrsa build-server-full "$SERVER_NAME" nopass

echo "Criando lista de certificados revogados"; sleep 1
./easyrsa gen-crl

echo "Criando chave DH"; sleep 1
./easyrsa gen-dh
