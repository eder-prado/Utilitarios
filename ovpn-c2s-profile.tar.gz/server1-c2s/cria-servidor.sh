#!/bin/bash

source variaveis.txt

echo "local "$REMOTE_IP"
port "$PORT"
server "$VPN_NETWORK" 255.255.255.0
proto "$PROTO"
dev-type tun
persist-key
persist-tun" > "$DIR_CONF"
for ROTA in ${ROTA[@]}
do
   echo "push \"route "$ROTA"\"" >> "$DIR_CONF"
done
for DNS in ${DNS[@]}
do
	echo "push \""dhcp-option DNS "$DNS""\"" >> "$DIR_CONF"
	echo "push \""dhcp-option WINS "$DNS""\"" >> "$DIR_CONF"
done

echo "push \"dhcp-option DOMAIN aker.com.br\"" >> "$DIR_CONF"
echo "dev tun"$SERVER_NAME"
ca "$OPENVPN_DIR"/"$SERVER_NAME"/easyrsa3/pki/ca.crt
dh "$OPENVPN_DIR"/"$SERVER_NAME"/easyrsa3/pki/dh.pem
crl-verify "$OPENVPN_DIR"/"$SERVER_NAME"/easyrsa3/pki/crl.pem
cert "$OPENVPN_DIR"/"$SERVER_NAME"/easyrsa3/pki/issued/"$SERVER_NAME".crt
key "$OPENVPN_DIR"/"$SERVER_NAME"/easyrsa3/pki/private/"$SERVER_NAME".key
tls-server
topology subnet
client-config-dir "$OPENVPN_DIR"/"$SERVER_NAME"/ccd
ccd-exclusive
keepalive 10 120
cipher AES-256-CBC
auth SHA512
verb 0
status "$LOG_DIR"/"$SERVER_NAME"-status.log 10
log-append "$LOG_DIR"/"$SERVER_NAME".log
plugin /usr/lib/openvpn/plugins/fwopenvpn_auth_plugin.so 
writepid /var/run/openvpn."$SERVER_NAME".pid
status-version 1 
float
comp-lzo
daemon" >> "$DIR_CONF"
clear
echo -n "criando arquivo aguarde"
for i in 1 2 3; do echo -n '.'; sleep 1; done
echo -e "\narquivo criado!"; sleep 1
echo 

# Incializacao do servidor
openvpn --config "$OPENVPN_DIR"/"$SERVER_NAME"/"$SERVER_NAME.conf"
RESULTADO="$?"

echo -n "iniciando servidor, aguarde"

for i in 1 2 3; do echo -n '.'; sleep 1; done; sleep 1

if [[ "$RESULTADO" -eq '0' ]];then
   echo -e "\nservidor iniciado com sucesso"; sleep 1
   ps aux|grep openvpn|grep ""$SERVER_NAME".conf"
   else
      echo -e "\nErro ao iniciar Servidor!!!\n"; sleep 1
      sleep 1
      echo -e "\t *** Favor Verifique os logs ***"; sleep 1
      tail "$LOG_DIR"/"$SERVER_NAME".log
fi

