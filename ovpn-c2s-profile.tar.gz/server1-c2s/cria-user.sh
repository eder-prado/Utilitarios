#!/bin/bash

# -------------------------------+
# *** NOME DO SERVIDOR ***
# !!! Deve ser o mesmo nome do subdiretorio 
# de trabalho e do arquivo de configuracao
# * "$OPENVPN_DIR"/server1
# * "$OPENVPN_DIR"/server1/server1.conf
# -------------------------------+
source variaveis.txt

# Funcao para imprimir texto colorido e/ou negrito
# ------------------------------------------------
imprime() {
	local formatacao=$1; local texto=$2
	case $formatacao in
		vermelho) echo -ne "\033[1;31m$texto\033[m" ;;
		verde)    echo -ne "\033[1;32m$texto\033[m" ;;
		amarelo)  echo -ne "\033[1;33m$texto\033[m" ;;
		negrito)  echo -ne "\033[1m$texto\033[m"    ;;
		*)	  echo -ne "$texto"                 ;;
	esac
}

# Verifica se o arquivo serial.txt existe
# ---------------------------------------
if ! [ -e ""$OPENVPN_DIR"/"$SERVER_NAME"/.serial.txt" ]; then
        touch "$OPENVPN_DIR"/"$SERVER_NAME"/.serial.txt 2> /var/null
        echo "2" > "$OPENVPN_DIR"/"$SERVER_NAME"/.serial.txt
fi
SERIAL=$(cat "$OPENVPN_DIR"/"$SERVER_NAME"/.serial.txt)

# Funcao do menu geral
# --------------------
menu_geral() {
clear
imprime verde "Gerenciador de Usuarios OpenVPN\n\n"

imprime negrito "[1] Listar Usuario(s)\n"
imprime negrito "[2] Criar Usuario\n"
imprime negrito "[3] Remover Usuario\n"
imprime negrito "[0] Sair\n\n"
imprime negrito "Digite a opcao desejada: "
read -s -n 1 opcao;
clear

case $opcao in
	# Lista o CN dos user ja' criados
	1) lista_user ;;

	# Cria o certificado e os arquivos necessarios para um novo user
	2) cria_user ;;

	# Revoga o certificado do user e remove todos os arquivos referente a esse user
	3) remove_user	;;

	0) exit	;;

	*) echo "" ;  imprime vermelho "Opcao Invalida\n\n" ; sleep 1 ; echo "" 	;;
esac
}

menu_continua(){
        imprime negrito "Deseja voltar ao MENU inicial? [s/n]: "
        read -s -n 1 opcao
	case $opcao in 
			s|S) menu_geral ;;
			*) echo && exit 0 ;;
	esac
}

lista_user() {
	imprime verde "Lista de usuarios validos:\n\n"
	cat "$OPENVPN_DIR"/"$SERVER_NAME"/easyrsa3/pki/index.txt | egrep ^V | awk '{print $5}' | cut -d= -f2
	echo
	imprime vermelho "Lista de usuarios revogados:\n\n"
	cat "$OPENVPN_DIR"/"$SERVER_NAME"/easyrsa3/pki/index.txt | egrep ^R | awk '{print $6}' | cut -d= -f2
	echo
	menu_continua
}

cria_user() {
	imprime verde "Entre com o nome do user: "
	read user
	echo

	# Muda para o diretorio do easyRSA3
	#
	cd "$OPENVPN_DIR"/"$SERVER_NAME"/easyrsa3

	# Executa o script easyrsa para criacao do certificado
	#
	./easyrsa build-client-full "$user" nopass >> /dev/null

	# Cria associacao do user com um endereco IP especifico
	echo "ifconfig-push "$VPN_NETWORK"."$SERIAL" 255.255.255.0" > "$OPENVPN_DIR"/"$SERVER_NAME"/ccd/$user

	# Cria o arquivo de configuracao do user de VPN
	#
	echo -e "client\ndev tun\nproto tcp\nresolv-retry 60\nnobind\npersist-key\npersist-tun\nremote-cert-tls server\n<ca>" > "$OPENVPN_DIR"/"$SERVER_NAME"/user/"$user".ovpn

	cat "$OPENVPN_DIR"/"$SERVER_NAME"/easyrsa3/pki/ca.crt >> "$OPENVPN_DIR"/"$SERVER_NAME"/user/"$user".ovpn
	echo -e "</ca>\n<cert>" >> "$OPENVPN_DIR"/"$SERVER_NAME"/user/"$user".ovpn

	cat "$OPENVPN_DIR"/"$SERVER_NAME"/easyrsa3/pki/issued/"$user".crt | grep -A 19 BEGIN >> "$OPENVPN_DIR"/"$SERVER_NAME"/user/"$user".ovpn
	echo -e "</cert>\n<key>" >> "$OPENVPN_DIR"/"$SERVER_NAME"/user/"$user".ovpn

	cat "$OPENVPN_DIR"/"$SERVER_NAME"/easyrsa3/pki/private/"$user".key >> "$OPENVPN_DIR"/"$SERVER_NAME"/user/"$user".ovpn
	echo -e "</key>\nauth-user-pass\ncomp-lzo\ncipher AES-256-CBC\nauth SHA512\nfloat\nverb 1\nremote "$REMOTE_IP" "$PORT"" >> "$OPENVPN_DIR"/"$SERVER_NAME"/user/$user.ovpn

	# Incrementa o arquivo ""$OPENVPN_DIR"/.serial.txt".
	#
	SERIAL=$(( $(cat "$OPENVPN_DIR"/"$SERVER_NAME"/.serial.txt) + 1 ))
	echo "$SERIAL" > "$OPENVPN_DIR"/"$SERVER_NAME"/.serial.txt
	echo
	imprime verde "O arquivo de configuracao esta salvo em "$OPENVPN_DIR"/"$SERVER_NAME"/user/"$user".ovpn\n\n"
	echo
	
	echo
	menu_continua

}

remove_user() {
	# Revoga o certificado do user selecionado
	#
	cat "$OPENVPN_DIR"/"$SERVER_NAME"/easyrsa3/pki/index.txt | egrep ^V | awk '{print $5}' | cut -d= -f2
	echo
	imprime verde "Entre com o nome do usuario: "
	read user
	echo

	# Muda para o diretorio do easyRSA3
	#
	cd "$OPENVPN_DIR"/"$SERVER_NAME"/easyrsa3

	./easyrsa revoke "$user"
	./easyrsa gen-crl

	# Remove arquivos do user
	#
	rm -f "$OPENVPN_DIR"/"$SERVER_NAME"/clientes/"$user".ovpn
	rm -f "$OPENVPN_DIR"/"$SERVER_NAME"/ccd/"$user"
	
	imprime verde "Usuario "$user" removido.\n\n"

        imprime negrito "Deseja reiniciar o servico do OpenVPN agora? [s/n]: "
        read -s -n 1 opcao
        	if [ "$opcao" = s ] || [ "$opcao" = S ]; then
			echo
			PID="$(ps aux|grep openvpn|grep "$SERVER_NAME".conf|awk '{print $2}')"
			kill $PID || echo "erro ao reiniciar servico" 
			sleep 1
			openvpn --config "$OPENVPN_DIR"/"$SERVER_NAME"/"$SERVER_NAME".conf
			echo
        	fi

		menu_continua
}

menu_geral
